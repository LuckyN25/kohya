### Novita

#### Pre-built Novita template

1. Open the Novita template by clicking on <https://novita.ai/gpus-console?templateId=312>.

2. Deploy the template on the desired host.

3. Once deployed, connect to the Novita on HTTP 7860 to access the kohya_ss GUI.
