# Preparing presets for users

Run the followinf command to prepare new presets for release to users:

```
python.exe .\tools\prepare_presets.py .\presets\finetune\*.json
```